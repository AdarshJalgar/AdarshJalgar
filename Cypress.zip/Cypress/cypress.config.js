// cypress run --record --key a5a0b205-7eaf-447b-bac0-d9b098633d4e

const { defineConfig } = require("cypress");
const   cucumber =require('cypress-cucumber-preprocessor').default
module.exports = (on,config)=>{
  	on('file:preprocessor', cucumber())
	}	
  


module.exports = defineConfig({
  projectId: '7ydejj',
  chromeWebSecurity: false, 
  fixturesFolder:"cypress/fixtures",
  defaultCommandTimeout:7000,
  requestTimeout: 7000,

   
  
   
  // experimentalSessionAndOrigin:true,
  env:{
    //"url":"https://appsteer.azurefd.net",
    "url":"https://etracksfmdev.azurewebsites.net/",
    "username":"arvind@appsteer.io",
    "password":"admin@123",
  
  },
  
    "compilerOptions": {
      "types": ["cypress", "@4tw/cypress-drag-drop"]
    },
  
  

    //"experimentalSessionAndOrigin": true,

  
    "reporter": "cypress-mochawesome-reporter",
    "reporterOptions": {
       "reportDir": "cypress/report",
       "overwrite": true,
       "charts":true,
       "html": true,
       "json": false
    },
    
  
  
  e2e: {
    baseUrl:"https://appsteer.azurefd.net",
    setupNodeEvents(on, config) {
  
     require('cypress-mochawesome-reporter/plugin')(on)
     require("cypress-localstorage-commands/plugin")(on, config);
     return config;
      
      // implement node event listeners here,
      
    },
  },

 
});
 