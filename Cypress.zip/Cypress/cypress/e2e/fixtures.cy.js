/// <reference types="cypress"/>
describe('mytestsuite',function(){
    before(function(){
        cy.fixture('example').then(function(data){
            this.data=data

        })
    })
    it('fixturedemo',function(){
        cy.visit('https://appsteer.azurefd.net')
        cy.get(':nth-child(1) > .input-md').type(this.data.username)
        cy.get('.p-password > .p-inputtext').type(this.data.password)
        cy.get('.btn-lg').click()
        cy.wait(9000)
        cy.get('.icon-view_form').click()
cy.wait(10000)
        cy.get('#detect-oveflw0 > :nth-child(2) > .grid-bg > .grid-img > img').click()//select web 
        cy.wait(7000)
        cy.get('#mat-tab-label-0-4').click()//click to data
        cy.get('.add-data > .p-button').click()//add data
        //cy.get('.details.ng-touched > .field-wrapper > app-text-field.ng-star-inserted > .form-group > :nth-child(2) > .input-md').type('adarsh')
        cy.get('input[placeholder="Username"]').type('Adarsh')
      //  cy.get(':nth-child(3) > .field-wrapper > app-text-field.ng-star-inserted > .form-group > :nth-child(2) > .input-md').type('9876543210')
      cy.get('input[placeholder="Phone NUmber"]').type('9876543210')
      cy.get('input[placeholder="Email"]').type('adasrh.j@isteer.com')
      cy.get('input[placeholder="Address"]').type('BTM')
      cy.get('input[placeholder="Text"]').type('Test')
      cy.get(':nth-child(6) > .star').click()
      cy.get('.p-calendar > .p-inputtext').focus().clear().type('2022-07-10')
      cy.get('.p-datepicker-trigger').click()//select date
     // cy.get('.bg-img > img').click()
     cy.get('.static-image').click()
   //  cy.get('.image-Capture > .ng-star-inserted').click()
    // cy.get('.ng-star-inserted > .icon-xlg').click()
    cy.get('input[type="file"]').attachFile('image.jpg')
    //cy.get('.p-button-label').click({multiple:true})
    //cy.get('button[label="UPLOAD"]').dblclick()
   // cy.get('.p-slider-handle').window().scrollTo('bottom')
    
    cy.get('button[label="UPLOAD"]').click()

    // cy.get('#cdk-step-label-0-1 > .mat-step-icon').click()
    })
})