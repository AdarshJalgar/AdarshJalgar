describe('profile',()=>{
    it('profile test',()=>{
        cy.request({
                  method : 'GET',
                  url : 'https://appsteer.azurefd.net/services/web/form/Profile?formUUID=10272d93-65e9-4e26-b730-fb5a0fc90787',
                  headers : {
                      authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnZpbmRAYXBwc3RlZXIuaW8iLCJyb2xlIjoiQ09SUE9SQVRFX0FETUlOIiwicm9sZUlkIjoyLCJ0ZW5hbnRJZCI6MzY0LCJleHAiOjE2NjI2MjI5NDAsImlhdCI6MTY2MjU1MDk0MH0.204ATiPSH3EnezDuXMOl9tyKvd2EtLq1sXgepOBtlaA'}
              }).then(function(res){
                cy.log(res)
                 expect(res.body)
              })
    })
})
// it('profile test',()=>{
//     const login = new FormData();
//     login.append("username", "arvind@appsteer.io")
//     login.append("password", "admin@123")
//     cy.request({
//               method : 'PUT',
//               url : 'https://appsteer.azurefd.net/services/web/form/Profile',
//               headers : {
//                   authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnZpbmRAYXBwc3RlZXIuaW8iLCJyb2xlIjoiQ09SUE9SQVRFX0FETUlOIiwicm9sZUlkIjoyLCJ0ZW5hbnRJZCI6MzY0LCJleHAiOjE2NjI2MjM4OTUsImlhdCI6MTY2MjU1MTg5NX0.ObK3uTUxqXpKrwodXfvfJ4U_uOMN-nkVCdbwKosKy4U'},
//                   body: login
//                 }).then(function (response) {
//                     expect(response.headers.authorization)
//                 })
// })
// })