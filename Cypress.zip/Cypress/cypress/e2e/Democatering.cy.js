/// <reference types="cypress"/>
let list;
describe('Catering Module',()=>{
        before(()=>{
            cy.fixture('fix').then((data)=>{
                cy.log(data)
                list=data
                cy.log(list)
            })
    })
    it('validate test case',()=>{
       // cy.log(list)
       // cy.login();
        cy.visit('https://appsteer.azurefd.net')
        cy.get(':nth-child(1) > .input-md').type(list.username)
        cy.get('.p-password-input').type(list.password)
        cy.get('.btn-lg').click()
        cy.get(':nth-child(9) > div.ng-star-inserted').click()
        // cy.get('.adddata > .p-button-rounded').click()
        cy.get('.icon-btn > .mat-menu-trigger').click()
        cy.get('.adddata').click()
        cy.get('.p-inputtext').focus().clear().type(list.Date)
        cy.get('.p-datepicker-trigger').click()
        cy.get(':nth-child(6) > .star').click()
       // cy.get('#mat-radio-2').should('be.visible').check().should('be.checked').click()
        // cy.get('#mat-radio-3').should('be.visible').should('not.be.checked').click()
        //cy.get('#mat-radio-2').click(list.Quantity)
        cy.get('#mat-radio-2').click()
        cy.get('#mat-radio-9').click()
        cy.get('#mat-radio-13').click()
        cy.get('.form-footer > :nth-child(2)').click()
        cy.get('.icon-avatar').click()
        cy.get('.mat-menu-content > :nth-child(2)').click()
        
        

            // cy.get('#mat-radio-4').click()
            // cy.get('#mat-radio-10').click()
            // cy.get('#mat-radio-15').click()
            // cy.get(':nth-child(6) > .star').click()
            // cy.get('.form-footer > :nth-child(2)').click()  
            // cy.get('.icon-avatar').click()
            // cy.get('.mat-menu-content > :nth-child(2)').click()
    })
})
