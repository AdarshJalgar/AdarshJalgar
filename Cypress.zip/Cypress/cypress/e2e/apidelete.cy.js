describe('api delete',()=>{
    it('delete',()=>{
    cy.request({
        method : 'DELETE',
        url : 'https://appsteer.azurefd.net/services/mobile/RemoveData?recordId=220822102853377',
        headers : {
            authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnZpbmRAYXBwc3RlZXIuaW8iLCJyb2xlIjoiQ09SUE9SQVRFX0FETUlOIiwicm9sZUlkIjoyLCJ0ZW5hbnRJZCI6MzY0LCJleHAiOjE2NjE1NjIwMjQsImlhdCI6MTY2MTQ5MDAyNH0.vdaF_2GHwZAIZVNKvoTYoadKw2MW339MeWwYm94HVJs'}
    }).then(function(response){
      cy.log(response)
       expect(response.headers.authorization)
              
    })
})
})
