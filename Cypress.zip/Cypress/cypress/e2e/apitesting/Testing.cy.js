describe('testing api',()=>{

    //test api get method
    // it('Get',()=>{
    //     cy.request('GET','https://localhost:44366/api/Cars/get-all-cars')
    //         .then((response)=>{
    //             expect(response.status).equal(200)
    // })
    // })


//test api post method

// it('POST',()=>{
// cy.request({
//     method: 'POST',
//     url: 'https://localhost:44366/api/Cars/add-car', 
//   //  form: true, // indicates the body should be form urlencoded and sets Content-Type: application/x-www-form-urlencoded headers
//     body: {
//         carName: "Maruti",
//         carColour:"white",
//         price: 300000,
//         modelNo: 2007
//     }
   
//   }) .then((response)=>{
//                 expect(response.status).equal(200)
//         })
// })


//test api get by id method

// it('get by id',()=>{
//     cy.request({
//         method:'GET',
//         url:'https://localhost:44366/api/Cars/get-Car-by-id/1'
//     }).then((response)=>{
//         expect(response.status).equal(200)
//     })

//     })

// it('Delete',()=>{
//     cy.request({
//         method:'DELETE',
//         url: 'https://localhost:44366/api/Cars/delete-car-by-id/18' 
//     }).then((response)=>{
//         expect(response.status).equal(200)
//     })
    
// })

it('Put',()=>{
    cy.request({
        method:'PUT',
        url: 'https://localhost:44366/api/Cars/update-car-by-id/21',
        body: {
                     carName: "Maruti",
                     carColour:"white",
                     price: 300000,
                     modelNo: 2007
                 }
    }).then((response)=>{
        expect(response.status).equal(200)
    })      


})


})
