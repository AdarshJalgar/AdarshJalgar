let list;
describe('Catering Module',()=>{
        before(()=>{
            cy.fixture('Lang').then((data)=>{
                cy.log(data)
                list=data
                cy.log(list)
            })      
    })
    it('validate',()=>{
        cy.login()//custom command
        cy.get('[routerlink="a/application"]').click()
        cy.get('#detect-oveflw0 > :nth-child(1) > .grid-bg > .grid-img > img').click()
        cy.get('#mat-tab-label-0-4').click()
        cy.get('.add-data > .p-button').click()
        cy.get(':nth-child(2) > .input-md').type(list.Text)
       // cy.get('.form-group > .input-md').type(list.Numeric)
        cy.get('.dropdown-md').click()  
        cy.get(':nth-child(1) > .p-dropdown-item').click()
    
       // cy.get('input[type="file"]').attachFile('CSS notes.pdf')
        // cy.get('.static-image').click()
         cy.get('.ng-star-inserted > .icon-xlg').attachFile('image.jpg')
        // //cy.get('.image-Capture > .ng-star-inserted').attachFile('image.jpg')

        

    })
})