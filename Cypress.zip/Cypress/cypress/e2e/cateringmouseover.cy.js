/// <reference types="cypress"/>
describe('visi',()=>{
    it('visi',()=>{
        cy.visit('https://appsteer.azurefd.net')
    })

    it('username',()=>{
        cy.get(':nth-child(1) > .input-md').should('be.enabled').should('be.visible').type('thanushreeg@appsteer.in')
        cy.get('.p-password-input').should('be.enabled').should('be.visible').type('Thanu@1234')
        cy.get('.btn-lg').click();
        //cy.setupPage(); // page setup function, no problems in all other test blocks
        cy.wait(10000);
        cy.contains('catering').trigger('mouseover').click()
    //   cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
    //   cy.contains('Catering Form')
    // //     cy.get('.icon-btn > .mat-menu-trigger').click()
    // cy.get('.mat-menu-trigger > .p-button-icon').click()
    // cy.get('.button-container.ng-star-inserted').click()
    // //    // cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
    //         cy.get('.p-inputtext').focus().clear().type('2022-08-07')
    //         cy.get('.p-datepicker-trigger').click()
    //         cy.get('#mat-radio-2').click()//quantity radio button
    //         cy.get('#mat-radio-8 > .mat-radio-label').click()
    //         cy.get('#mat-radio-13').click()//quality radio button
    //         cy.get(':nth-child(6) > .star').click()
    //         cy.get('.form-footer > :nth-child(2)').click()  
    })

})