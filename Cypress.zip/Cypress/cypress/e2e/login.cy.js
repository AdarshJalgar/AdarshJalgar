import{Given,When,And,Then} from "cypress-cucumber-preprocessor/steps";

Given('A user opens the Login page ',()=>{
    cy.visit('/')
})
When('A user enter the usename {string}',(username)=>{
    cy.get('[data-test="username"]').should('be.visible').should('be.enabled').type(username)

})