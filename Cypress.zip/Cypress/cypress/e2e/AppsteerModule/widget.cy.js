describe('Widget module Automation',()=>{
   
    before(()=>{
    cy.visit('/')//baseUrl in Cypress.config.js folder
    cy.LoginPage();//All the Login details in  commands.js file
})
beforeEach(()=>{
    Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
    cy.restoreLocalStorage();
    Cypress.Cookies.debug(true)
})
//     it('navigate to analytics menu',()=>{
//     cy.get('[routerlink="a/analytics"]').should('be.visible').click()
// })
 it('Click on analytics menu',()=>{
    cy.get('[routerlink="a/analytics"]').should('be.visible').click()

    cy.get('[routerlink="/a/analytics/widget"]').click() 
    cy.get('.create-app > .p-button').should('be.visible').should('be.enabled').click()   
 })
 it('creating a base table',()=>{
    cy.get(':nth-child(6) > img').click()
    cy.get('input[placeholder="Chart Header"]').clear().type('Leave Demo')//chart header
    cy.get('input[placeholder="Chart Description"]').clear().type('Causal leave')//chart description
//    cy.get('.p-multiselect-label ng-tns-c137-222 p-placeholder').click()

 })
 it('Enter all data mapping details',()=>{
cy.get('.p-grid > :nth-child(1) > .form-group > .ng-untouched > .p-multiselect').click()
cy.get(':nth-child(11) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()
cy.get('.p-md-4.ng-star-inserted').click()
//cy.get('.ng-star-inserted').contains('Testing289 Type')
//cy.get('p-checkbox-box').contains('Testing289 Start Time').click()
cy.get(':nth-child(86) > .p-multiselect-item').click()
cy.get(':nth-child(87) > .p-multiselect-item').click()
cy.get(':nth-child(88) > .p-multiselect-item').click()
cy.get(':nth-child(89) > .p-multiselect-item').click()
cy.get(':nth-child(90) > .p-multiselect-item').click()
 })
 it('Adding limit data ',()=>{
    cy.get('input[placeholder="Limit Value"]').clear().type(50)
   
    //cy.get('input[type="button"]').click()
    cy.get('.cube-config > :nth-child(2) > .page-header > .accordion-toggle > .flex-sb > .p-button-rounded').click()
    // cy.get('pi icon-down_arrow icon-lg').click()
    cy.get('.cube-config > :nth-child(2) > .page-header > .accordion-toggle > .flex-sb > .flex-m > .pi').click()
 })
 it("select sort setting",()=>{
    cy.get('[style="display: flex; width: 90%;"] > [style="padding-left: 0;"]').click()
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Cube Testing Id")
               {
               cy.wrap(elem).click()
                }
            })
    cy.get('[style="display: flex; width: 90%;"] > :nth-child(2)').click()
    //cy.get('#p-accordiontab-6-content > .p-accordion-content > .p-grid > :nth-child(1)').click()
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Ascending")
               {
               cy.wrap(elem).click()
                }   
            }) 
 })
it('selecting a avatar type',()=>{
    cy.get(':nth-child(1) > .page-header > .accordion-toggle > .flex-sb > .flex-m > .pi').click()
    cy.get('.p-accordion-content > .p-grid > :nth-child(1) > .ng-untouched > .filter-block').click()
    cy.get('li[role="option"]')
    //cy.get('[optionvalue="name"]').click()
    .each(function(elem)
            {
               if(elem.text()==="Cube Testing Type")
               {
               cy.wrap(elem).click()
                }
            })
        })
 it('click on create button',()=>{
    cy.get('.update-action > .p-button-rounded').click()
    
    })

 })

    
afterEach(()=>{
    cy.saveLocalStorage();

})