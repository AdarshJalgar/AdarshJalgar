/// <reference types="cypress"/>

describe('Cube module Automation',()=>{
   
        before(()=>{
        cy.visit('/')//baseUrl in Cypress.config.js folder
        cy.LoginPage();//All the Login details in  commands.js file
    })
    beforeEach(()=>{
        Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
        cy.restoreLocalStorage();
        Cypress.Cookies.debug(true)
    })
    it('visit to integration page',()=>{
        
        //cy.customCommand('arvind@appsteer.io','admin@123')
        cy.get('[routerlink="a/integration"]').click()
        cy.get('#mat-tab-label-0-3').click()
    })

    // it('Edit  the cube',()=>{
    //     cy.get('[ptooltip="Edit"]').first().click()
    //     cy.get('.p-col-4 > .p-inputtext').clear().type('Demo3')
    //     cy.get('.btnPad').click()
    //     cy.wait(5000)

    // })
    // it('delete the cube',()=>{
    //     cy.get('[ptooltip="Delete"]').first().click()
    // })



    it('Add Analytics API',()=>{
        cy.get(':nth-child(2) > .p-button').should('be.be.visible').click()
    })
    it('add cube name',()=>{
        cy.get('.p-col-4 > .p-inputtext').should('be.enabled').should('be.visible').type('Testing201')
        cy.get(':nth-child(2) > .ng-pristine > .dropdown-status > .p-dropdown-label').click()
        cy.get('li[role="option"]').should('have.length',3)
        .each(function(elem)
                {
                   if(elem.text()==="App Data")
                   {
                   cy.wrap(elem).click()
                    }
                })
    })
    it('Application Name',()=>{
        cy.get('.p-col-4.ng-star-inserted > .ng-untouched').click()
        cy.get('li[role="option"]')
        .each(function(elem)
                {
                   if(elem.text()==="Leave Process")
                   {
                   cy.wrap(elem).click()
                    }
                })
    })
    it('Select Fields',()=>{
        cy.get('p-table.ng-star-inserted > .p-datatable > .p-datatable-wrapper > table > .p-datatable-tbody > tr.ng-star-inserted > :nth-child(1)') .click()
        cy.get('#mat-checkbox-1 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave type
        cy.get('#mat-checkbox-3 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave start date
        cy.get('#mat-checkbox-5 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave end date
        cy.get('#mat-checkbox-7 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select no of days
        cy.get('#mat-checkbox-8 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select measure
        cy.get('[placeholder="Measure Type"]').eq(3).click()//eq(3) among 4 measure type selecting a 3rd measure type  
        cy.get('li[role="option"]')
        .each(function(elem)
                {
                   if(elem.text()==="Count")
                   {
                   cy.wrap(elem).click()
                    }
                })
    })
    it('Add the cube',()=>{
        cy.get('.btnPad').click()
        
      cy.get('.p-button-label').contains('CANCEL').click({force:true})     
     cy.get('[ptooltip="Edit"]').first().click()   
     cy.get('.p-col-4 > .p-inputtext').clear().type("CubeTesting")//edit the cube Name
     cy.get('.btnPad').click()
    })

    
})
afterEach(()=>{
    cy.saveLocalStorage();

})
