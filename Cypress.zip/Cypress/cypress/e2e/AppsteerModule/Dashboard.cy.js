describe('Automate the dashboard',()=>{
    before(()=>{
        cy.visit('/')//baseUrl in Cypress.config.js folder
        cy.LoginPage();//All the Login details in  commands.js file
    })
    beforeEach(()=>{
        Cypress.Cookies.preserveOnce('_ga_RN    P1ZNLWQG', '_ga')
        cy.restoreLocalStorage();
        Cypress.Cookies.debug(true)
    })
   
    it('Click on analytics menu and add dashboard ',()=>{
        cy.get('[routerlink="a/analytics"]').should('be.visible').click()
        cy.get('.create-app > .p-button').click()
        
    })
    it('Add created widget',()=>{
       // cy.get('[type="text"]').contains('Dashboard Name').type('Leave application')
      cy.get('form.ng-untouched > .ng-star-inserted > .ng-untouched').type('Leave application')
       cy.get('form.ng-untouched > .ng-star-inserted > .ng-untouched')
        cy.get('#4').click()//click on widget component
        cy.get(':nth-child(1) > .grid-bg > .widget-img').click()//select created widget
        cy.get('.p-dialog-footer > :nth-child(2)').click()//click on add
        cy.get('.dashwidget').click()
        cy.viewport(1000,800)     
  
    })
     it('drag and drop',()=>{
        
        //cy.get('.p-button-icon icon-time').drag('.mobile')
         cy.get('#1').drag('.mobile')
        // const dataTransfer=new DataTransfer();
        //     cy.get('#3').trigger('dragstart', {
        //     dataTransfer
        //   });
       
        //   cy.get('.mobile').trigger('drop', {
        //     dataTransfer
        //   });
          
          
      

        //cy.get('.app-update').click()
        //cy.wait(7000)
       // cy.get(':nth-child(12) > .grid-bg > .grid > .icon-btn > [icon="pi icon-edit iconbtn-sm"]').click()
       // cy.get('#3').drag('.mobile')\
    //     const dataTransfer=new DataTransfer();//Another method for drag and drop
    //     cy.get('#3').trigger('dragstart', {
    //     dataTransfer
    //   });
   
    //   cy.get('.mobile').trigger('drop', {
    //     dataTransfer
    //   });
    // })
    //   it('drag and drop',()=>{
    //     const dataTransfer=new DataTransfer();
    //     cy.get('#3').trigger('dragstart', {
    //     dataTransfer
    //   });
   
    //   cy.get('.mobile').trigger('drop', {
    //     dataTransfer
    //   });
      
      
        //  cy.get('#1').drag('.mobile')
        //  cy.find('#3').drag('.mobile')
        //  cy.get('.squareicon-btn p-button p-component p-button-icon-only').drag('.mobile')
        //cy.get('.p-button-label').drag('.mobile')
//         cy.get('[type="button"]')
//         .each(function(elem)
//             {
//                if(elem.text()==="Marquee" & "Text")
//                {
//                cy.wrap(elem).click()
//                 }
           
// })

     })
    })
    
    afterEach(()=>{
        cy.saveLocalStorage();
    
    })
