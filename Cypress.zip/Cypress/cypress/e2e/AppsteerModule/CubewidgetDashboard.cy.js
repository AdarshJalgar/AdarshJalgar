let list;
/// <reference types="cypress"/>
describe('Cube and widget module Automation',()=>{
    before(()=>{
    cy.visit('/')//baseUrl in Cypress.config.js folder
    cy.LoginPage();//All the Login details in  commands.js file
})
beforeEach(()=>{
    Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
    cy.restoreLocalStorage();
    Cypress.Cookies.debug(true)
})
it.skip('visit to integration page',()=>{   
    //cy.customCommand('arvind@appsteer.io','admin@123')
    cy.get('[routerlink="a/integration"]').click()
    cy.get('#mat-tab-label-0-3').click()
})
it.skip('Add Analytics API',()=>{
    cy.get('.page-header > :nth-child(2) > .p-button').click()
})
it.skip('add cube name',()=>{
    cy.fixture('Cube').then((data)=>{
        cy.log(data)
        list=data
        cy.log(list)    
    cy.get('.p-col-4 > .p-inputtext').should('be.enabled').should('be.visible').type(list.CubeName)
    cy.get(':nth-child(2) > .ng-pristine > .dropdown-status > .p-dropdown-label').click()
    cy.get('li[role="option"]').should('have.length',3)
    .each(function(elem)
            {
               if(elem.text()==="App Data")
               {
               cy.wrap(elem).click()
                }
            })
        })
    })

it.skip('Application Name',()=>{
    cy.get('.p-col-4.ng-star-inserted > .ng-untouched').click()
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Leave Process")
               {
               cy.wrap(elem).click()
                }
            })
})
it.skip('Select Fields',()=>{
    cy.get('p-table.ng-star-inserted > .p-datatable > .p-datatable-wrapper > table > .p-datatable-tbody > tr.ng-star-inserted > :nth-child(1)') .click()
    cy.get('#mat-checkbox-1 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave type
    cy.get('#mat-checkbox-3 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave start date
    cy.get('#mat-checkbox-5 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select leave end date
    cy.get('#mat-checkbox-7 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select no of days
    cy.get('#mat-checkbox-8 > .mat-checkbox-layout > .mat-checkbox-inner-container').click()//select measure
    cy.get('[placeholder="Measure Type"]').eq(3).click()//eq(3) among 4 measure type selecting a 3rd measure type  
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Count")
               {
               cy.wrap(elem).click()
                }
           })
})
it.skip('Add the cube',()=>{
    cy.get('.btnPad').click() 
    cy.wait(4000)
cy.get('.p-button-label').contains('CANCEL').click()//Cube to widget creation
 })
 //creating a widget
 it('Click on analytics menu',()=>{
    cy.fixture('Cube').then((data)=>{
        cy.log(data)
        list=data
        cy.log(list) 
    cy.get('[routerlink="a/analytics"]').should('be.visible').click()
    cy.get('[routerlink="/a/analytics/widget"]').click() 
    cy.get('.create-app > .p-button').should('be.visible').should('be.enabled').click()   
    
    cy.get(':nth-child(7) > .chart-name').click()
    cy.wait(7000)
 })
})
 it('creating a App  table',()=>{
   
   
    cy.get('.field-wrapper > :nth-child(1) > .p-inputtext').type(list.header)//chart header
    cy.get('.field-wrapper > :nth-child(2) > .p-inputtext').type(list.description)//chart description
    cy.get('.field-wrapper > .form-group.ng-star-inserted').click()
    cy.get('li[role="option"]')
    .each(function(elem)
    {
       if(elem.text()==="Testing0169")
       {
       cy.wrap(elem).click()
       cy.wait(20000)
        }
    })
 })
 it('Enter all data mapping details',()=>{
    cy.get('.cube-config > :nth-child(1) > .p-grid > .p-col-6.ng-star-inserted').click()
    cy.get(':nth-child(5) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()
    cy.get(':nth-child(1) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()
    cy.get(':nth-child(2) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()
    cy.get(':nth-child(3) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()
    cy.get(':nth-child(4) > .p-multiselect-item > .p-checkbox > .p-checkbox-box').click()  
 })
 it('Adding limit data ',()=>{
    cy.get('input[placeholder="Limit Value"]').clear().type(50)
    cy.get('.cube-config > :nth-child(2) > .page-header > .accordion-toggle > .flex-sb > .p-button-rounded').click()
    cy.get('.cube-config > :nth-child(2) > .page-header > .accordion-toggle > .flex-sb > .flex-m > .pi').click()
 })
 it("select sort setting",()=>{
    cy.get('[style="display: flex; width: 90%;"] > [style="padding-left: 0;"]').click()
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Testing0169 Id")
               {
               cy.wrap(elem).click()    
                }
            })
            cy.get('[style="display: flex; width: 90%;"] > :nth-child(2)').click()
    cy.get('li[role="option"]')
    .each(function(elem)
            {
               if(elem.text()==="Ascending")
               {
               cy.wrap(elem).click()
                }   
            }) 
 })
it('selecting a avatar type',()=>{
    cy.get(':nth-child(1) > .page-header > .accordion-toggle > .flex-sb > .flex-m > .pi').click()
    cy.get('.p-accordion-content > .p-grid > :nth-child(1) > .ng-untouched > .filter-block').click()
    cy.get('li[role="option"]')
    //cy.get('[optionvalue="name"]').click()
    .each(function(elem)
            {
               if(elem.text()==="Testing0168 Id")   
               {
               cy.wrap(elem).click()
                }
            })
        })
 it('click on create button',()=>{
    cy.get('.update-action > .p-button-rounded').click()
    
    })
    //creating a dashboard
    it('Click on analytics menu and add dashboard ',()=>{
        cy.get('[routerlink="a/analytics"]').should('be.visible').click()
        cy.get('.create-app > .p-button').click()
    })
    it('Add created widget',()=>{
        // cy.get('[type="text"]').contains('Dashboard Name').type('Leave application')
        cy.get('form.ng-untouched > .ng-star-inserted > .ng-untouched').type('Leave application')
         cy.get('#4').click()
         cy.get(':nth-child(1) > .grid-bg > .widget-img > img').click({force:true})
         cy.get('.p-dialog-footer > :nth-child(2)').click({force:true})
         cy.get('.dashwidget').click({force:true})
         cy.viewport(1000,800)  
     })
      it('select component use drag and drop method ',()=>{
         cy.get('#1').drag('.mobile')
        //  cy.get('#3').drag('.mobile')
      })
      
     it('Edit the dashboard name',()=>{
        cy.get(':nth-child(10) > .grid-bg > .grid > .icon-btn > [icon="pi icon-edit iconbtn-sm"]').click()
        cy.get('form.ng-untouched > .ng-star-inserted > .ng-untouched').clear().type('Application for leave') 
        cy.get('.app-update').click()
     })
    }) 


afterEach(()=>{
    cy.saveLocalStorage();
})
