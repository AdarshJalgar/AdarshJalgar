/// <reference types="cypress"/>

describe('file upload',()=>{
    it('file upload',()=>{
   
        cy.visit('https://appsteer.azurefd.net')
        cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('arvind@appsteer.io')
        cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@123')
       // cy.wait(7000)
        cy.get('.btn-lg').click()
        //cy.wait(5000)
     
        cy.get('.icon-view_form').click()
      //  cy.wait(5000)
        cy.get('#detect-oveflw0 > :nth-child(1) > .grid-bg > .grid-items').click()
        cy.get('#mat-tab-label-0-4').click()//click data
       // cy.wait(5000)
        cy.get('.add-data > .p-button').click()

      //  cy.wait(3000)
       // cy.get(':nth-child(2) > .input-md').type('test')
        //cy.get('input[formcontrolname="value"]').type('test')
        //cy.get('input[formcontrolname="value"]').type('testing')
        cy.get(':nth-child(2) > .input-md').type('testing')
       // cy.wait(1000)
   

       cy.get('input[type="file"]').attachFile('CSS notes.pdf')
       cy.get('.form-group > .input-md').type(1)
       cy.get('.form-footer > :nth-child(2)').click()
     
    //    cy.get('.p-calendar > .p-inputtext').focus().clear().type('2022-08-10')
    //    cy.wait(3000)
    //    cy.get('.p-datepicker-trigger').click()
      // cy.get('.form-footer > :nth-child(2)').click()//submit
    //    cy.wait(8000)
    //    cy.get(':nth-child(1) > .sticky-action > .icon-btn > [icon="icon-preview"] > .p-button-icon').click()
    })
})
