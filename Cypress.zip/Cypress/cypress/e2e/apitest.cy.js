describe('file upload',()=>{
    it('file upload',()=>{
      // const fileName = 'CSS notes.pdf'
      cy.request({
        method : 'POST',
        url : 'https://appsteer.azurefd.net/services/web/login',
        body: {
           username : 'uiux@mailinator.com',
           password: 'admin@1234'
       }
    }).then(function(response){
        cy.log(response)

        expect(response.body)
     
        // cy.visit('https://appsteer.azurefd.net')
        //  cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('uiux@mailinator.com')
        //  cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@1234')
        //  cy.get('.btn-lg').should('be.enabled').should('be.visible').click()
   
    
    // cy.request({
    //       method : 'GET',
    //       url : 'https://appsteer.azurefd.net/services/web/form/GetAllForms',
    //       headers : {
    //           authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1aXV4QG1haWxpbmF0b3IuY29tIiwicm9sZSI6IkNPUlBPUkFURV9BRE1JTiIsInJvbGVJZCI6MiwidGVuYW50SWQiOjM1OCwiZXhwIjoxNjYxNTU5NTcyLCJpYXQiOjE2NjE0ODc1NzJ9.cTahPSNztitVgCXNS9a0y_PyNJnRZ1-VaMQ02HgCmZw'}
    //   }).then(function(res){
    //     cy.log(res)
    //      expect(res.body)
    //      cy.visit('https://appst eer.azurefd.net')
    //          cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('uiux@mailinator.com')
    //            cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@1234')
    //            cy.get('.btn-lg').should('be.enabled').should('be.visible').click()
    //            cy.get('.icon-view_form').click()

    // cy.request({
    //   method:'GET',
    //   url:'https://appsteer.azurefd.net/services/workflow/get',
    //   headers:{
    //     authorization:'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1aXV4QG1haWxpbmF0b3IuY29tIiwicm9sZSI6IkNPUlBPUkFURV9BRE1JTiIsInJvbGVJZCI6MiwidGVuYW50SWQiOjM1OCwiZXhwIjoxNjYwODc3ODg5LCJpYXQiOjE2NjA4MDU4ODl9.fudC9T-dOt9yfj0RZQKpnVMEo1pFGs7f9oe9f1NFEm0'}
      
    // }).then(function(response){
    //   cy.log(response.body)
    //   expect(response)
            
    })
       })
      })
    

    