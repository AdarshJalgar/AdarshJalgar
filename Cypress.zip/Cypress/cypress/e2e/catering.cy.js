/// <reference types="cypress"/>
describe('Catering Module',()=>{
    it('visi',()=>{
        cy.visit('https://appsteer.azurefd.net')
    })
    it('username',()=>{
        cy.get(':nth-child(1) > .input-md').should('be.enabled').should('be.visible').type('thanushreeg@appsteer.in')
        cy.get('.p-password-input').should('be.enabled').should('be.visible').type('Thanu@1234')
        cy.get('.btn-lg').click()
        cy.wait(9000)
       cy.get('.icon-g-shopping').click()
       cy.get('.adddata > .p-button-rounded').click()    
            cy.get('.p-inputtext').focus().clear().type('2022-08-07')
            cy.get('.p-datepicker-trigger').click()
            cy.get('#mat-radio-4').click()
            cy.get('#mat-radio-10').click()
            cy.get('#mat-radio-15').click()
            cy.get(':nth-child(6) > .star').click()
            cy.get('.form-footer > :nth-child(2)').click()  
    })
})