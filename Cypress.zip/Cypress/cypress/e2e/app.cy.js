describe('react org screenshot',()=>{
    it('url',()=>{
       cy.visit('https://reactjs.org/')
       cy.screenshot()
    })
    // it('invalid-username',()=>{
    //     cy.get(':nth-child(1) > .input-md').should('be.enabled').should('be.visible').type('thanushreeg@appster.in')
    //     //cy.should('have.value','thanushreeg@appsteer.in')
    // })
    // it('password',()=>{
    //     cy.get('.p-password-input').should('be.enabled').should('be.visible').type('Thanu@1234')
    //     //cy.should('have.value','Thanu@1234')
    //     cy.get('.btn-lg').should('be.enabled').should('be.visible').click()
    //     cy.get('.p-toast-message-content').should('have.text','Error')
       
    // })

    // it('valid username',()=>{
    //     cy.visit('https://appsteer.azurefd.net')
    //     cy.get(':nth-child(1) > .input-md').should('be.enabled').should('be.visible').type('thanushreeg@appsteer.in')
    //     cy.should('have.value','thanushreeg@appsteer.in')
    // })
    // it('password',()=>{
    //     cy.get('.p-password-input').should('be.enabled').should('be.visible').type('Thanu@1234')
    //     cy.should('have.value','Thanu@1234')
    //     cy.get('.btn-lg').should('be.enabled').should('be.visible').click()
        //cy.get('.router-gap > app-agent-header.ng-star-inserted > .header > .user-login > .mat-menu-trigger > .icon-avatar').click()
        //cy.get('.mat-menu-content > :nth-child(1)').click()
       //cy.url().should('include','u/userportal')
       //cy.get(':nth-child(1) > .sticky-action > .icon-btn > [icon="icon-edit iconbtn-md"]').click()
       //cy.get(':nth-child(1) > .countdown_timer-text').click()
   // })
    // it('HR',()=>{
    //     cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(3)').should('be.visible').click()
    //     cy.get('.icon-btn > .mat-menu-trigger').should('be.visible').click()
    //     cy.get(':nth-child(1) > .countdown_timer-text').click()
    //     // cy.get('.button-container.ng-star-inserted').click()
        //cy.get('.mat-menu-content > .icon-btn > :nth-child(1)').click()
      //  cy.get('.bg-img > img').click()//select location
        //cy.get(':nth-child(9) > .field-wrapper > app-drop-down-field.ng-star-inserted > .dropdown-formfield > .dropdown-md > .p-dropdown > .p-dropdown-trigger').click()
  
        // cy.get('.filter').click()
        // cy.get('.bg-img > img').click()//location
        // cy.get(':nth-child(9) > .field-wrapper > app-drop-down-field.ng-star-inserted > .dropdown-formfield > .dropdown-md > .p-dropdown > .p-dropdown-label').click()
        // cy.get(':nth-child(3) > .p-dropdown-item > .option-elem > span').click()
        // cy.get(':nth-child(10) > .field-wrapper > app-drop-down-field.ng-star-inserted > .dropdown-formfield > .dropdown-md > .p-dropdown > .p-dropdown-label').click()
        // cy.get(':nth-child(1) > .p-dropdown-item > .option-elem > span').click()
    // it('select project',()=>{
    //     cy.get(':nth-child(10) > .field-wrapper > app-drop-down-field.ng-star-inserted > .dropdown-formfield').click()
    // })
})
