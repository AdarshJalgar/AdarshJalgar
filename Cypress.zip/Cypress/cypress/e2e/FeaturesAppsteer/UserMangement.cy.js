let list;
describe('user ',()=>{
   before(()=>{
   cy.visit('/')//baseUrl in Cypress.config.js folder
//     cy.LoginPage();//All the Login details in  commands.js file
 })
beforeEach(()=>{
    Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
    cy.restoreLocalStorage();
    Cypress.Cookies.debug(true)
})
// it('Service Change for Take a Tour Option',()=>{
//     cy.get('[routerlink="a/settings"]').click()
//     cy.get('[routerlink="/a/settings/user-manage"]').click()
//     cy.get(':nth-child(2) > .p-button').click()//create user
// })
// it('add user details',()=>{
//     cy.fixture('userDetails').then((data)=>{
//         cy.log(data)
//         list=data
//         cy.log(list)
//     cy.get('[formcontrolname="name"]').should('be.visible').clear().type(list.Name)
// cy.get('[formcontrolname="userName"]').should('be.visible').clear().type(list.Username)
// cy.get('[formcontrolname="mailId"]').should('be.visible').clear().type(list.Emailid)
// cy.get('[formcontrolname="role"]').click()
// cy.get('li[role="option"]')
// .each(function(elem,index)
// {   
//    if(index == 7)
//    {
//    cy.wrap(elem).click()
//     }
// })

// cy.get('[formcontrolname="assignedGroups"]').click()
// cy.get('[aria-label="Agent"]').contains('Agent').click()
// cy.get('[aria-label="Applicant"]').contains('Applicant').click()
//  cy.get('[formcontrolname="designation"]').should('be.visible').clear().type(list.Designation)
//  cy.get('[formcontrolname="phoneNumber"]').should('be.visible').clear().type(list.phoneno)
//  //cy.get('[formcontrolname="reportingManager"]').should('be.visible').clear().type(list.ReportingManager)
//  cy.get('[formcontrolname="reportingManager"]').type('Jeyaraj')
//  cy.get('#pr_id_19_list > :nth-child(1)').click()

//  cy.get('.user-actions').contains('CREATE').click()

// })
// })
// it('logout',()=>{
//     cy.get('.userAvatar').click()
//     cy.get('.mat-menu-content > :nth-child(5)').click()
// })
it('new user login',()=>{
    cy.UserLoginPage();
})
it('change the password',()=>{
    cy.fixture('userDetails').then((data)=>{
                cy.log(data)
                list=data
                cy.log(list)

    cy.get('[formcontrolname="oldPassword"]').type(list.oldPassword)
    cy.get('[formcontrolname="newPassword"]').type(list.newPassword,{log:false})
    cy.get('[formcontrolname="confirmPassword"]').type(list.confimPassword)
    cy.get('[type="submit"]').click({force:true})

   })
})
    it('login',()=>{
        cy.UserLogin();
})

afterEach(()=>{
    cy.saveLocalStorage();
})
})


