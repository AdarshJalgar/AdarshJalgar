
/// <reference types="cypress"/>



describe(' Unable to delete the records in INTEGRATION (APIs and Cubes)',()=>{
    before(()=>{
        cy.visit('/')//baseUrl in Cypress.config.js folder
        cy.LoginPage();//All the Login details in  commands.js file
    })
    beforeEach(()=>{
        Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
        cy.restoreLocalStorage();
        Cypress.Cookies.debug(true)
    })
    it('Anonymous form is not loading',()=>{
        cy.get('[routerlink="a/integration"]').click()
        cy.get('#mat-tab-label-0-3').click()
        cy.get('.input-md').type('GGS')
        cy.viewport(2000,800)
      
        // cy.window().then((window) => {
        //     window.scrollTo(0, 0);
      //  cy.get('[role="grid"]').scrollTo('left');
        cy.get('[ptooltip="Delete"]').click({force:true})

        cy.get('.footer > :nth-child(2)').click()
    
       // cy.get('[role="alert"]').contains('Analytics API deleted successfully')
        cy.get('.input-md').clear().type('GGS')
        cy.get('.nodatafound > div').contains(' No Data found ')

   // cy.get('.p-datatable-wrapper').scrollIntoView({ offset: { top: 10, left: 190 } })
    //cy.get(':nth-child(3) > .p-button-rounded').click()
     })
    })

afterEach(()=>{
    cy.saveLocalStorage();

})
