let list;
describe('test',()=>{
    before(()=>{
        cy.visit('/')//baseUrl in Cypress.config.js folder
        cy.LoginPage();//All the Login details in  commands.js file
    })
    beforeEach(()=>{
        Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
        cy.restoreLocalStorage();
        Cypress.Cookies.debug(true)
    })
    it('testcase',()=>{
       
        cy.get('[routerlink="a/application"]').click()
        cy.get('#detect-oveflw0 > :nth-child(3) > .grid-bg > .grid-img > img').click()
        cy.get('#mat-tab-label-0-4 > .mat-tab-label-content').click()
        cy.get('.add-data > .p-button').click()
        cy.fixture('module').then((data)=>{
            cy.log(data)
            list=data
            cy.log(list)
            cy.get(':nth-child(2) > .input-md').type(list.Text)
            cy.get('[placeholder="Date Picker"]').focus().clear().type('2022-09-09')
            cy.get('.p-datepicker-trigger').click()
            cy.wait(4000)
                //cy.get('.form-group > .input-md').type(list.Numeric)
                cy.get('input[type="file"]').attachFile('CSS notes.pdf')
              //cy.get('.upload-wrap').contains('Upload / Capture Image').attachFile('image.jpg')
            })
        })
           
            it('click on preview',()=>{
            cy.get('[label="PREVIEW"]').click()
                cy.get('[label="CANCEL"]').click()
                cy.get('.form-footer > :nth-child(2)').click()
            })
            // it('delete the record',()=>{
            //     cy.get("icon-delete").first().click()
            //     cy.get('.p-button-rounded p-button p-component p-button-icon-only ng-star-inserted').first().click()
            // })

        
           
        
    
    afterEach(()=>{
        cy.saveLocalStorage();
    
    })
})

