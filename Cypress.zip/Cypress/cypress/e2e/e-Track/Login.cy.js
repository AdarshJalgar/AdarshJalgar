describe('navigate to url',()=>{
    it('Navigate to login page',()=>{
        cy.visit('https://etracksfmdev.azurewebsites.net/')
    })
})