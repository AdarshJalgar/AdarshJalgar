describe('iframe',()=>{
    it('demo iframe',()=>{
        cy.visit('https://the-internet.herokuapp.com/iframe')
        cy.get('#mce_0_ifr').type('hello')
    })
})