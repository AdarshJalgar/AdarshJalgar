describe('testing',()=>{
    it('demo',()=>{
        cy.visit('https://demo.automationtesting.in/Register.html')
        cy.get(':nth-child(1) > :nth-child(2) > .form-control').type('adarsh')
        cy.get(':nth-child(1) > :nth-child(3) > .form-control').type('j')
        cy.get('.col-md-8 > .form-control').type('BTM')
    })
})