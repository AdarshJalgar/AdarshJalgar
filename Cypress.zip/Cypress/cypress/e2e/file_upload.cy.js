describe('file upload test cases',()=>{
 it('simple file upload',()=>{
    
   // const fileName = 'image.jpg'
    cy.visit('https://fineuploader.com/demos.html')
    
    //cy.get('#fine-uploader-gallery > .qq-uploader-selector').click()
    cy.get('#fine-uploader-gallery > .qq-uploader-selector > .qq-upload-button-selector > input').attachFile('image.jpg')
    })
})
    