describe('cucumber demo',()=>{
    it('sucess login',()=>{
        cy.visit('/')
       cy.sucess('standard_user','secret_sauce')
       cy.url().should('contain','inventory.html')
    })
})