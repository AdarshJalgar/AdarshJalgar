describe('cucumber demo',()=>{
    it('success login',()=>{
        cy.visit('/')
        cy.get('[data-test="username"]').should('be.visible').should('be.enabled').type('standard_user')
        cy.get('[data-test="password"]').should('be.visible').should('be.enabled').type('secret_sauce')
        cy.get('[data-test="login-button"]').click( )
       
       cy.url().should('contain','inventory.html')
    })
})