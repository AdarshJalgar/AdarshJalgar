
/// <reference types="cypress"/>



describe('Appsteer portal',()=>{
  it('visit',()=>{

        cy.visit('https://appsteer.azurefd.net')
        
        //cy.wait(10000);
        
})

    it('enter user name',()=>{
        cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('thanushreeg@appsteer.in')
        cy.should('have.value','thanushreeg@appsteer.in')

    })
    it('enter password',()=>{
        cy.get('.p-password-input').should('be.visible').should('be.enabled').type('Thanu@1234')
        cy.should('have.value','Thanu@1234')
    })
    it('click to login',()=>{
        cy.get('.btn-lg').should('be.enabled').click()
        cy.wait(9000)
       // cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
       cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(6)').click() 
       //cy.wait(20000)
    //cy.get('.icon-btn > .mat-menu-trigger').click()
    cy.get('.icon-btn > .mat-menu-trigger').click()
    cy.get('.mat-menu-content > .icon-btn > :nth-child(1)').click()
            //cy.url().should('include','u/userportal')
            // cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7) > .icon-g-shopping').click()
            cy.get('.footer > .p-button-rounded').click()
            cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('thanushreeg@appsteer.in')
            cy.get('.p-password-input').should('be.visible').should('be.enabled').type('Thanu@1234')
            cy.get('.btn-lg').should('be.enabled').click()
            //cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
            cy.get('icon-g-shopping ng-star-inserted').click()
            cy.get('.p-datepicker-next').click()
                cy.wait(2000)
                cy.get('.p-datepicker-next').click()
                // cy.get('tbody.ng-tns-c61-10 > :nth-child(2) > :nth-child(5) > .ng-tns-c61-10').click()
                cy.get(':nth-child(4) > :nth-child(3) > .ng-tns-c61-10').click()//select date
                // cy.get('#mat-radio-2-input').first().check({force: true})
                // cy.get('#mat-radio-2').should('be.checked')
                cy.get('#mat-radio-3').click()
                // cy.get('[type="radio"]').check()
                cy.get('#mat-radio-8 > .mat-radio-label > .mat-radio-label-content').click()
                cy.get('#mat-radio-13 > .mat-radio-label > .mat-radio-label-content').click()
                // cy.get(':nth-child(5) > .star').click()
                //     cy.get('.form-footer > :nth-child(2)').click()
                cy.get(':nth-child(5) > .star').should('be.enabled').should('be.be.visible').click()
                cy.get('.form-footer > :nth-child(2) > .p-button-label').should('be.enabled').should('be.be.visible').click()

    })
//  it('select catering menu button',()=>{

    // cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
    // cy.get('.icon-btn > .mat-menu-trigger').click()
  
    // cy.get('.mat-menu-content > .icon-btn > :nth-child(1)').click({force:true})
    //         //cy.url().should('include','u/userportal')
    //         // cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7) > .icon-g-shopping').click()
    //         cy.get('.footer > .p-button-rounded').click()
    //         cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('thanushreeg@appsteer.in')
    //         cy.get('.p-password-input').should('be.visible').should('be.enabled').type('Thanu@1234')
    //         cy.get('.btn-lg').should('be.enabled').click()
    //         //cy.get('.router-gap > app-agent-header.ng-star-inserted > .sidebar > .sidebar-icons > :nth-child(7)').click()
    //         cy.get('icon-g-shopping ng-star-inserted').click()
    //         cy.get('.p-datepicker-next').click()
    //             cy.wait(2000)
    //             cy.get('.p-datepicker-next').click()
    //             // cy.get('tbody.ng-tns-c61-10 > :nth-child(2) > :nth-child(5) > .ng-tns-c61-10').click()
    //             cy.get(':nth-child(4) > :nth-child(3) > .ng-tns-c61-10').click()//select date
    //             // cy.get('#mat-radio-2-input').first().check({force: true})
    //             // cy.get('#mat-radio-2').should('be.checked')
    //             cy.get('#mat-radio-3').click()
    //             // cy.get('[type="radio"]').check()
    //             cy.get('#mat-radio-8 > .mat-radio-label > .mat-radio-label-content').click()
    //             cy.get('#mat-radio-13 > .mat-radio-label > .mat-radio-label-content').click()
    //             // cy.get(':nth-child(5) > .star').click()
    //             //     cy.get('.form-footer > :nth-child(2)').click()
    //             cy.get(':nth-child(5) > .star').should('be.enabled').should('be.be.visible').click()
    //             cy.get('.form-footer > :nth-child(2) > .p-button-label').should('be.enabled').should('be.be.visible').click()
 })






