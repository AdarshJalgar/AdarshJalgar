describe('iframe',()=>{
    it('demo iframe',()=>{
        cy.visit('https://the-internet.herokuapp.com/iframe')
        cy.get('#mce_0_ifr').within(function($iFrame){//instead of then we can also used within method
            const iFreameContent = $iFrame.contents().find('body')
            cy.wrap(iFreameContent)
            .clear()
            //.click()
            .type('hello')

        })
    })
}) 