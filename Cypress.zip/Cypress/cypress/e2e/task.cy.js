// Bug 4250 : Anonymous form is not loading
/// <reference types="cypress"/>

describe('Cube and widget module Automation',()=>{
    before(()=>{
    cy.visit('/')//baseUrl in Cypress.config.js folder
    cy.LoginPage();//All the Login details in  commands.js file
})
beforeEach(()=>{
    Cypress.Cookies.preserveOnce('_ga_RNP1ZNLWQG', '_ga')
    cy.restoreLocalStorage();
    Cypress.Cookies.debug(true)
})
it('visit to form menu',()=>{
    cy.get('[routerlink="a/application"]').click()
    cy.get('.formname').contains('Leave Type').click()
    cy.get('#mat-tab-label-0-3').click()//select profile
    cy.get('.profile-header > .transcparent-bg').click()   //click on profile
    cy.get('.profile > .name > .p-inputtext').clear().type('Testing')  
    
    cy.get(':nth-child(3) > .p-inputwrapper-filled > .p-calendar > .p-inputtext').focus().clear().type('22-08-2027')
    //cy.get('.ng-dirty > .p-calendar > .p-datepicker-trigger').click  
    cy.get('.create-app > .p-button').click()
  
})

})

afterEach(()=>{
    cy.saveLocalStorage();

})