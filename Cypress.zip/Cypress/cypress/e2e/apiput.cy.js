describe('api post', () => {
    it('post', () => {
        const login = new FormData();
        login.append("username", "arvind@appsteer.io")
        login.append("password", "admin@123")
        cy.request({
            method: 'PUT',
            url: 'https://appsteer.azurefd.net/services/mobile/SaveUserForm',
            body: login
        }).then(function (response) {
            expect(response.headers.authorization)
        })

    })
})
