describe('custom command',()=>{
    it('log',()=>{
    cy.login();
    
})
})

