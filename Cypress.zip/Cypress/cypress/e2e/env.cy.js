let list;
describe('test',()=>{
    it('testcase',()=>{
        const username = Cypress.env('username')
        const password = Cypress.env('password')
        cy.visit(Cypress.env('url'))
        cy.get(':nth-child(1) > .input-md').type(username,{log:false})
        cy.get('.p-password-input').type(password,{log:false})
        cy.get('.btn-lg').click()
        cy.get('[routerlink="a/application"]').click()
        cy.get('#detect-oveflw0 > :nth-child(3) > .grid-bg > .grid-img > img').click()
        cy.get('#mat-tab-label-0-4 > .mat-tab-label-content').click()
        cy.get('.add-data > .p-button').click()
        cy.fixture('module').then((data)=>{
            cy.log(data)
            list=data
            cy.log(list)
            cy.get(':nth-child(2) > .input-md').type(list.Text)
           
        
            cy.get('.dropdown-md > .p-dropdown > .p-dropdown-label').click()
        cy.get("li[role='option']").should('have.length',4)
        .each(function(elem)
                {
                   if(elem.text()==="ADARSH")
                   {
                   cy.wrap(elem).click()
                    }
                })
                cy.get('.form-group > .input-md').type(list.Numeric)
                cy.get('input[type="file"]').attachFile('CSS notes.pdf')
            //    cy.get('.form-footer > :nth-child(2)').click()
            cy.wait(5000)

            cy.get('.form-footer > :nth-child(2)').click()
        })
})
    })
