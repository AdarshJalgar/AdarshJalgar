

/// <reference types="cypress"/>

//describe('Second Test', () => {
    it('nopcommerce page visit', ()=>{
      cy.visit('https://demo.nopcommerce.com/')
      cy.get('.ico-login').click()
  
    
     cy.get('.new-wrapper > .buttons > .button-1').click()
     cy.get('[type="radio"]').check('F')
//   cy.get ('[type="radio"]').each(function($ele, index, list){
//      if($ele.text()==="M"){
//       cy.log("found element")
//       cy.wrap($ele).click()
//   }
//   else{
//       cy.log("current value", $ele.text())
//   }
     
      cy.get('#FirstName').should('be.visible').should('be.enabled').type('Adarsh')
      cy.should('have.value','Adarsh')
      cy.get('#LastName').type('Jalgar')
      cy.should('have.value','Jalgar')
      cy.wait(2000)
      cy.get('[name="DateOfBirthDay"]').should('be.enabled').should('be.visible').select('26')
      cy.get('[name="DateOfBirthMonth"]').should('be.enabled').should('be.visible').select('August')
      cy.get('[name="DateOfBirthYear"]').select('1999')
      cy.get('#Email').type('adarshadi93@gmail.com')
      cy.get('#Company').type('isteer technology')
      cy.get('#Password').type('addi@#123')
      cy.get('#ConfirmPassword').type('addi@#123')
      cy.wait(2000)
      cy.get('#register-button').should('be.enabled').should('be.visible').click()
      cy.get('.buttons > .button-1').click()
      cy.get('#small-searchterms').should('be.enabled').should('be.visible').type('Build your own computer')
      cy.get('#small-search-box-form > .button-1').click()
      cy.get('.product-box-add-to-cart-button').click()
      cy.get('#product_attribute_label_2')
      cy.get('#product_attribute_2').select('5')
      cy.get('#product_attribute_label_3 > .text-prompt')
      cy.get('#product_attribute_3_6').should('be.enabled').should('be.visible').click()
      cy.get('#add-to-cart-button-1').should('be.enabled').should('be.visible').click()
      cy.wait(3000)
      cy.get('#add-to-wishlist-button-1').should('be.visible').click()
      

    
     })
 

