describe('api post', () => {
    it('post', () => {
        const login = new FormData();
        login.append("username", "uiux@mailinator.com")
        login.append("password", "admin@1234")
        cy.request({
            method: 'POST',
            url: 'https://appsteer.azurefd.net/services/web/login',
            body: login
        }).then(function (response) {
            expect(response.headers.authorization)
        })

    })
})







// describe('api post', () => {
//     it('post', () => {
//         const login = new FormData();
//         login.append("username", "thanushreeg@appster.in")
//         login.append("password", "Thanu@1234")
//         login.append("attachFile","CSS notes.pdf")
//         cy.request({
//             method: 'POST',
//             url: 'https://appsteer.azurefd.net/services/mobile/SaveUserForm',
//             body: login
//         }).then(function (response) {
//             expect(response.headers.authorization)
//         })
//     })
// })