// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --

//import cypress = require("cypress")

//const cypress = require("cypress");

// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
//import 'cypress-file-upload';
require('@4tw/cypress-drag-drop')
Cypress.Commands.add('login',()=>{
    cy.visit('https://appsteer.azurefd.net')
   //  cy.get(':nth-child(1) > .input-md').type(Username)
   //  cy.get('.p-password-input').type(Password)
   cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('arvind@appsteer.io')
    cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@123',{sensitive:true})
    cy.get('.btn-lg').click()
})

Cypress.Commands.add('LoginPage',()=>{
    // cy.visit('https://appsteer.azurefd.net'
    cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('arvind@appsteer.io')
    cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@123',{log:false})

     cy.get('.btn-lg').click()
 })
 Cypress.Commands.add('UserLoginPage',()=>{
    // cy.visit('https://appsteer.azurefd.net'
    cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('AMJ@appsteer.in')
    cy.get('.p-password-input').should('be.visible').should('be.enabled').type('9vl3mt5t',{log:false})

     cy.get('.btn-lg').click()
 })
 Cypress.Commands.add('UserLogin',()=>{
    // cy.visit('https://appsteer.azurefd.net'
    cy.get(':nth-child(1) > .input-md').should('be.visible').should('be.enabled').type('AMJ@appsteer.in')
    cy.get('.p-password-input').should('be.visible').should('be.enabled').type('admin@1234#',{log:false})

     cy.get('.btn-lg').click()
 })











Cypress.Commands.add('sucess',(username,Password)=>{
   // cy.visit('https://appsteer.azurefd.net')
   //  cy.get(':nth-child(1) > .input-md').type(Username)
   //  cy.get('.p-password-input').type(Password)
   cy.get('[data-test="username"]').should('be.visible').should('be.enabled').type(username)
   cy.get('[data-test="password"]').should('be.visible').should('be.enabled').type(Password,{log:false})
   cy.get('[data-test="login-button"]').click()
   // cy.get('.btn-lg').click()
})
Cypress.Commands.overwrite('type',(originalFn,element,text,options)=>{
    if(options &&  options.sensitive){
        options.log=false
        Cypress.log({
            $el:element,
            name:'type',
            message :'*'.repeat(text.length),
        })
    }
    return originalFn(element,text,options)
})
